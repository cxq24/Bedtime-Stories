# 用户长稿 v5｜当前唯一有效剧本

更新：2026-11-12。用户已确定后续制作统一使用v5。当前工作树只保留v5作为剧本版本；旧版替代稿已移除，历史Git提交和各集制作快照用于追溯既有成片。

## 唯一稿源与阅读视图

- `结构化JSON/ep001.json`至`ep100.json`是001–100唯一有效、唯一可编辑的剧本源。
- `narration_paragraphs[].text`是口播内容；不要朗读标题、主题、制作说明或元数据。
- 阅读合集、片头清单和100份单集Markdown位于`../阅读与审校/用户长稿v5开场优化_v001/`，都是从JSON导出的视图，不是另一个稿源。
- 改稿先更新JSON，再执行`python3 local/export_opening_scripts.py --validate-only`；导出阅读视图时明确指定`--output-dir`并确认落入v5阅读目录。

## 片头与正文

001–100每集包含专属段落`p000`，标记`kind: opening_introduction`和`illustration_requirement: standalone`。配音、字幕和时间轴必须包含p000；分镜必须给片头单独安排镜头并生成专属插画，不能复用封面或第一张剧情图。

001–003保留各自的短正文；004–100为完整长稿。 角色图库索引文件名含“v4”是图库版本名，不代表剧本版本。所有集数都按对应v5 JSON完整朗读，不限五分钟，不删减、不整体拉伸音频。新任务不得从旧视频或历史工程快照取代v5稿源。

## 开始新集

先读`CHANNEL_MASTER.md`、`docs/production/EPISODE_STATUS.md`及本集专项规范，确认用户指定的集数、现有版本和素材；再读取本目录对应JSON。片头单独配图的流程见`docs/production/STORYBOARD_SPEC.md`。配音、镜头、字幕和音床依据本集完整文本与实际录音制作，并把实际版本写入工程RECORD。
